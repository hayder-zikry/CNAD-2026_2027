module rainfall

go 1.27.3
